import tkinter as tk
from tkinter import messagebox, simpledialog, colorchooser, ttk
import calendar
from datetime import datetime
import json
import os


class ResizableCalendar:
    def __init__(self, root):
        self.root = root
        self.root.title("Life Management")
        self.root.geometry("1500x700")
        now = datetime.now()
        self.current_year = now.year
        self.current_month = now.month
        self.today = (now.year, now.month, now.day)

        self.day_labels = []
        self.date_buttons = {}

        self.events = {}
        self.load_events()

        self.color_images = {}

        self.main_frame = tk.Frame(root, bg="lightyellow")
        self.main_frame.pack(expand=True, fill='both')

        self.calendar_container = tk.Frame(self.main_frame, bg="lightyellow")
        self.calendar_container.pack(side=tk.LEFT, expand=True, fill='both', padx=10, pady=10)

        self.nav_frame = tk.Frame(self.calendar_container, bg="lightyellow")
        self.nav_frame.pack(pady=5)

        self.prev_button = tk.Button(
            self.nav_frame, text="<< Prev", font=("Arial", 10), fg="blue",
            command=self.prev_month, relief="raised", borderwidth=2, padx=5, pady=2)
        self.prev_button.pack(side=tk.LEFT, padx=5)

        self.month_label = tk.Label(
            self.nav_frame,
            text=f"{calendar.month_name[self.current_month]} {self.current_year}",
            font=("Arial", 12, "bold"), bg="lightyellow")
        self.month_label.pack(side=tk.LEFT, padx=10)

        self.next_button = tk.Button(
            self.nav_frame, text="Next >>", font=("Arial", 10), fg="blue",
            command=self.next_month, relief="raised", borderwidth=2, padx=5, pady=2)
        self.next_button.pack(side=tk.LEFT, padx=5)

        self.calendar_frame = tk.Frame(self.calendar_container, bg="lightyellow")
        self.calendar_frame.pack(expand=True, fill='both', pady=10)

        self.create_calendar(self.current_year, self.current_month)

        # Event display sidebar
        self.events_container = tk.Frame(self.main_frame, width=400, bg="lightyellow")
        self.events_container.pack(side=tk.RIGHT, fill='both', padx=10, pady=10)

        # Event details section
        self.events_header = tk.Label(
            self.events_container, text="All Events", font=("Arial", 14, "bold"),
            bg="lightyellow")
        self.events_header.pack(pady=10)
        self.separator = ttk.Separator(self.events_container, orient='horizontal')
        self.separator.pack(fill='x', padx=10)

        # Create a dedicated frame to hold TreeView and scrollbar
        self.tree_frame = tk.Frame(self.events_container, bg="lightyellow")
        self.tree_frame.pack(fill='both', expand=True, padx=10, pady=5)

        # Use TreeView with four columns: Date, Description, Invitee Count, Invitees
        columns = ("Date", "Description", "Invitee Count", "Invitees")
        self.events_tree = ttk.Treeview(self.tree_frame, columns=columns, show='headings', selectmode='browse')
        self.events_tree.pack(side=tk.LEFT, fill='both', expand=True)

        self.events_tree.heading("Date", text="Date")
        self.events_tree.column("Date", width=100, anchor='center')

        self.events_tree.heading("Description", text="Description")
        self.events_tree.column("Description", width=200, anchor='w')

        self.events_tree.heading("Invitee Count", text="Invitee Count")
        self.events_tree.column("Invitee Count", width=100, anchor='center')

        self.events_tree.heading("Invitees", text="Invitees")
        self.events_tree.column("Invitees", width=150, anchor='w')

        self.scrollbar = ttk.Scrollbar(self.tree_frame, orient="vertical", command=self.events_tree.yview)
        self.scrollbar.pack(side=tk.RIGHT, fill='y')
        self.events_tree.configure(yscrollcommand=self.scrollbar.set)

        # Bind double-click event
        self.events_tree.bind("<Double-1>", self.on_event_double_click)

        # Operation buttons frame
        self.buttons_frame = tk.Frame(self.events_container, bg="lightyellow", relief="groove", borderwidth=2)
        self.buttons_frame.pack(pady=10, fill='x', padx=10)

        # Add Event button
        self.add_event_button = tk.Button(
            self.buttons_frame, text="Add Event", font=("Arial", 10), fg="green",
            command=self.add_event_globally, relief="raised", borderwidth=2, padx=10, pady=5)
        self.add_event_button.pack(side=tk.LEFT, padx=5)

        # Delete Event button
        self.delete_event_button = tk.Button(
            self.buttons_frame, text="Delete Selected Event", font=("Arial", 10),
            fg="red", command=self.delete_event_globally, relief="raised", borderwidth=2,
            padx=10, pady=5)
        self.delete_event_button.pack(side=tk.LEFT, padx=5)

        # Invite People button
        self.invite_event_button = tk.Button(
            self.buttons_frame, text="Invite People", font=("Arial", 10),
            fg="purple", command=self.invite_people_globally, relief="raised", borderwidth=2,
            padx=10, pady=5)
        self.invite_event_button.pack(side=tk.LEFT, padx=5)

        # Initialize all events in the sidebar
        self.update_all_events_sidebar()

    def create_calendar(self, year, month):
        """Create the calendar grid with events"""
        # Clear previous calendar content
        for label in self.day_labels:
            label.destroy()
        self.day_labels.clear()

        for btn_row in self.date_buttons.values():
            for btn, frame in btn_row:
                btn.destroy()
                frame.destroy()
        self.date_buttons.clear()

        cal = calendar.monthcalendar(year, month)
        days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

        for col, day in enumerate(days):
            lbl = tk.Label(
                self.calendar_frame, text=day, font=("Arial", 10, "bold"),
                width=12, height=1, bg="lightgray", borderwidth=1, relief="solid")
            lbl.grid(row=0, column=col, sticky="nsew", padx=1, pady=1)
            self.day_labels.append(lbl)

        for col in range(7):
            self.calendar_frame.columnconfigure(col, weight=1)
        for row in range(len(cal) + 1):
            self.calendar_frame.rowconfigure(row, weight=1)

        for row, week in enumerate(cal, start=1):
            btn_row = []
            for col, day in enumerate(week):
                if day == 0:  # Empty date
                    lbl = tk.Label(
                        self.calendar_frame, text="", font=("Arial", 10),
                        width=12, height=3, bg="white", borderwidth=1, relief="solid"
                    )
                    lbl.grid(row=row, column=col, sticky="nsew", padx=1, pady=1)
                else:
                    # Create a frame to hold the day label and events
                    day_frame = tk.Frame(
                        self.calendar_frame, bg="white", borderwidth=1, relief="solid"
                    )
                    day_frame.grid(row=row, column=col, sticky="nsew", padx=1, pady=1)
                    day_frame.columnconfigure(0, weight=1)
                    day_frame.rowconfigure(0, weight=1)

                    # Check if today
                    if (year, month, day) == self.today:
                        bg_color = "lightblue"
                    else:
                        bg_color = "white"

                    day_label = tk.Label(
                        day_frame, text=str(day), font=("Arial", 10, "bold"),
                        width=12, height=1, bg=bg_color, cursor="hand2"
                    )
                    day_label.grid(row=0, column=0, sticky="nsew")
                    day_label.bind(
                        "<Double-Button-1>",
                        lambda e, y=year, m=month, d=day: self.open_event_window(y, m, d)
                    )

                    # Create a frame for event color squares
                    events_frame = tk.Frame(day_frame, bg="white")
                    events_frame.grid(row=1, column=0, sticky="nsew")
                    events_frame.columnconfigure(0, weight=1)
                    events_frame.rowconfigure(0, weight=1)

                    if (year, month, day) in self.events:
                        for event in self.events[(year, month, day)]:
                            # Use small color squares to represent events
                            color_square = self.create_small_color_square(event.get("color", "#FFFF00"))
                            square_label = tk.Label(events_frame, image=color_square, bg="white")
                            square_label.image = color_square  # Prevent garbage collection
                            square_label.pack(side='left', padx=1, pady=1)

                    btn_row.append((day_label, events_frame))
            if btn_row:
                self.date_buttons[row] = btn_row

    def create_small_color_square(self, color_hex):
        """Create a small color square image (8x8) with specified color"""
        size = 8  # Reduced square size
        img = tk.PhotoImage(width=size, height=size)
        img.put(color_hex, to=(0, 0, size, size))
        return img

    def open_event_window(self, year, month, day):
        """Open the event management window for a specific date"""
        EventWindow(self, year, month, day)

    def prev_month(self):
        """Navigate to the previous month"""
        self.current_month -= 1
        if self.current_month == 0:  # If January, go to December of the previous year
            self.current_month = 12
            self.current_year -= 1
        self.update_calendar()

    def next_month(self):
        """Navigate to the next month"""
        self.current_month += 1
        if self.current_month == 13:  # If December, go to January of the next year
            self.current_month = 1
            self.current_year += 1
        self.update_calendar()

    def update_calendar(self):
        """Update the calendar display and month label"""
        self.create_calendar(self.current_year, self.current_month)
        self.month_label.config(text=f"{calendar.month_name[self.current_month]} {self.current_year}")
        # Update all events in the sidebar
        self.update_all_events_sidebar()

    def add_event_globally(self):
        """Add a global event without selecting a specific date"""
        # Prompt user to select a date
        date_selection = DateSelectionWindow(self)
        self.root.wait_window(date_selection.top)

    def delete_event_globally(self):
        """Delete the selected event from the global event list"""
        selected = self.events_tree.selection()
        if not selected:
            messagebox.showwarning("Delete Event", "Please select an event to delete.")
            return
        item = selected[0]
        values = self.events_tree.item(item, "values")
        date = values[0]
        description = values[1]

        # Parse date
        try:
            year, month, day = map(int, date.split('-'))
        except ValueError:
            messagebox.showerror("Delete Event", "Invalid date format.")
            return

        # Find and delete event
        key = (year, month, day)
        if key in self.events:
            for idx, event in enumerate(self.events[key]):
                if event["description"] == description:
                    del self.events[key][idx]
                    if not self.events[key]:
                        del self.events[key]
                    break
            self.save_events()
            self.update_calendar()
            self.update_all_events_sidebar()
            messagebox.showinfo("Delete Event", "Event deleted.")
        else:
            messagebox.showerror("Delete Event", "Unable to delete the selected event.")

    def invite_people_globally(self):
        """Invite people to the selected event from the global event list"""
        selected = self.events_tree.selection()
        if not selected:
            messagebox.showwarning("Invite People", "Please select an event to invite people.")
            return
        item = selected[0]
        values = self.events_tree.item(item, "values")
        date = values[0]
        description = values[1]

        # Parse date
        try:
            year, month, day = map(int, date.split('-'))
        except ValueError:
            messagebox.showerror("Invite People", "Invalid date format.")
            return

        # Find event
        key = (year, month, day)
        if key in self.events:
            for idx, event in enumerate(self.events[key]):
                if event["description"] == description:
                    self.invite_people(key, idx)
                    return
        messagebox.showerror("Invite People", "Unable to invite people to the selected event.")

    def invite_people(self, key, event_id):
        """Handle inviting people to a specific event"""
        event = self.events.get(key, [])[event_id]
        # Ask how many people to invite
        num_people = simpledialog.askinteger(
            "Invite People",
            "How many people would you like to invite?",
            parent=self.root,
            minvalue=1,
            maxvalue=100
        )

        if not num_people:
            return

        invitees = []
        for i in range(num_people):
            name = simpledialog.askstring(
                "Invite People",
                f"Enter name for person {i + 1}:",
                parent=self.root
            )
            if name:
                invitees.append(name)
            else:
                break

        if invitees:
            if 'invitees' not in event:
                event['invitees'] = []
            event['invitees'].extend(invitees)

            # Update display
            self.save_events()
            self.update_calendar()
            self.update_all_events_sidebar()
            messagebox.showinfo(
                "Invite People",
                f"Successfully invited {len(invitees)} people to the event."
            )

    def on_event_double_click(self, event):
        """Handle double-clicking an event in the global event list"""
        selected = self.events_tree.selection()
        if not selected:
            return
        item = selected[0]
        values = self.events_tree.item(item, "values")
        date = values[0]
        description = values[1]

        # Parse date
        try:
            year, month, day = map(int, date.split('-'))
        except ValueError:
            messagebox.showerror("Error", "Invalid date format.")
            return

        # Find event
        key = (year, month, day)
        if key in self.events:
            for idx, event in enumerate(self.events[key]):
                if event["description"] == description:
                    # Open the event editing window
                    EventWindow(self, year, month, day, event_id=idx)
                    return
        messagebox.showerror("Error", "Unable to open the selected event.")

    def update_all_events_sidebar(self):
        """Update the sidebar to display all events"""
        # Clear existing items
        for item in self.events_tree.get_children():
            self.events_tree.delete(item)
        self.color_images.clear()

        all_events = self.get_all_events_sorted()
        for idx, event in enumerate(all_events):
            date = event['date']
            description = event['description']
            invitees = event.get('invitees', [])
            invitee_count = len(invitees)
            invitees_str = ', '.join(invitees) if invitees else 'None'

            color_hex = event.get('color', '#FFFF00')

            # Insert into TreeView
            self.events_tree.insert('', tk.END, values=(date, description, invitee_count, invitees_str), tags=(str(idx),))
            # Set row background color to event color
            self.events_tree.tag_configure(str(idx), background=color_hex)

    def get_all_events_sorted(self):
        """Retrieve all events sorted by date"""
        all_events = []
        for (year, month, day), events in self.events.items():
            for event in events:
                event_copy = event.copy()
                event_copy['year'] = year
                event_copy['month'] = month
                event_copy['day'] = day
                event_copy['date'] = f"{year}-{month:02d}-{day:02d}"
                all_events.append(event_copy)
        # Sort by date
        all_events.sort(key=lambda x: (x['year'], x['month'], x['day']))
        return all_events

    def load_events(self):
        """Load events from a file"""
        if os.path.exists("events.json"):
            try:
                with open("events.json", "r", encoding='utf-8') as f:
                    events = json.load(f)
                    self.events = {tuple(map(int, k.split('-'))): v for k, v in events.items()}
            except (json.JSONDecodeError, ValueError) as e:
                messagebox.showerror("Error", f"Failed to load event file: {e}")
                self.events = {}
        else:
            self.events = {}

    def save_events(self):
        """Save events to a file"""
        with open("events.json", "w", encoding='utf-8') as f:
            json.dump({"-".join(map(str, k)): v for k, v in self.events.items()}, f, ensure_ascii=False, indent=4)


class EventWindow:
    def __init__(self, calendar_app, year, month, day, event_id=None):
        self.calendar_app = calendar_app
        self.year = year
        self.month = month
        self.day = day
        self.event_id = event_id  # If editing a specific event, it is the event ID; otherwise, None

        self.top = tk.Toplevel()
        self.top.title(f"Events on {year}-{month:02d}-{day:02d}")
        self.top.geometry("500x400")
        self.top.configure(bg="lightyellow")

        # Event list frame
        self.events_frame = tk.Frame(self.top, bg="lightyellow")
        self.events_frame.pack(fill='both', expand=True, padx=10, pady=10)

        self.events_label = tk.Label(
            self.events_frame, text="Event List:", font=("Arial", 12, "bold"),
            bg="lightyellow"
        )
        self.events_label.pack(anchor='w')

        # Create a dedicated frame to hold TreeView and scrollbar
        self.tree_frame = tk.Frame(self.events_frame, bg="lightyellow")
        self.tree_frame.pack(fill='both', expand=True, pady=5)

        # Use TreeView with three columns: Description, Invitee Count, Invitees
        columns = ("Description", "Invitee Count", "Invitees")
        self.events_tree = ttk.Treeview(self.tree_frame, columns=columns, show='headings', selectmode='browse')
        self.events_tree.pack(side=tk.LEFT, fill='both', expand=True)

        # Define columns
        self.events_tree.heading("Description", text="Description")
        self.events_tree.column("Description", width=200, anchor='w')

        self.events_tree.heading("Invitee Count", text="Invitee Count")
        self.events_tree.column("Invitee Count", width=100, anchor='center')

        self.events_tree.heading("Invitees", text="Invitees")
        self.events_tree.column("Invitees", width=150, anchor='w')

        # Add vertical scrollbar
        self.scrollbar = ttk.Scrollbar(self.tree_frame, orient="vertical", command=self.events_tree.yview)
        self.scrollbar.pack(side=tk.RIGHT, fill='y')
        self.events_tree.configure(yscrollcommand=self.scrollbar.set)

        # Bind double-click event
        self.events_tree.bind("<Double-1>", self.on_event_double_click)

        # Operation buttons frame
        self.buttons_frame = tk.Frame(self.top, bg="lightyellow", relief="groove", borderwidth=2)
        self.buttons_frame.pack(pady=10, fill='x', padx=10)

        # Add Event button
        self.add_event_button = tk.Button(
            self.buttons_frame, text="Add Event", font=("Arial", 10), fg="green",
            command=self.add_event, relief="raised", borderwidth=2, padx=10, pady=5)
        self.add_event_button.pack(side=tk.LEFT, padx=5)

        # Delete Event button
        self.delete_event_button = tk.Button(
            self.buttons_frame, text="Delete Selected Event", font=("Arial", 10),
            fg="red", command=self.delete_event, relief="raised", borderwidth=2,
            padx=10, pady=5)
        self.delete_event_button.pack(side=tk.LEFT, padx=5)

        # Invite People button
        self.invite_event_button = tk.Button(
            self.buttons_frame, text="Invite People", font=("Arial", 10),
            fg="purple", command=self.invite_people, relief="raised", borderwidth=2,
            padx=10, pady=5)
        self.invite_event_button.pack(side=tk.LEFT, padx=5)

        # Prevent images from being garbage collected
        self.color_images = {}
        self.populate_events()

    def populate_events(self):
        """Populate events in the event list frame"""
        # Clear existing items
        for item in self.events_tree.get_children():
            self.events_tree.delete(item)
        self.color_images.clear()

        # Get event list
        if self.event_id is not None:
            # Display a single event when editing a specific event
            events = [self.calendar_app.events.get((self.year, self.month, self.day), [])[self.event_id]]
        else:
            # Display all related events when viewing all events
            events = self.calendar_app.events.get((self.year, self.month, self.day), [])

        for idx, event in enumerate(events):
            description = event["description"]
            invitees = event.get("invitees", [])
            invitee_count = len(invitees)
            invitees_str = ', '.join(invitees) if invitees else 'None'

            self.events_tree.insert('', tk.END, values=(description, invitee_count, invitees_str), tags=(str(idx),))
            self.events_tree.tag_configure(str(idx), background=event.get('color', '#FFFF00'))

    def add_event(self):
        """Add a new event"""
        description = simpledialog.askstring("Add Event", "Please enter the event description:", parent=self.top)
        if not description:
            return

        # Choose color
        color = colorchooser.askcolor(title="Select Event Color")[1]
        if not color:
            color = "#FFFF00"  # Default to yellow

        new_event = {"description": description, "color": color}
        key = (self.year, self.month, self.day)
        if key in self.calendar_app.events:
            self.calendar_app.events[key].append(new_event)
        else:
            self.calendar_app.events[key] = [new_event]

        self.calendar_app.save_events()
        self.populate_events()
        self.calendar_app.create_calendar(self.calendar_app.current_year, self.calendar_app.current_month)
        self.calendar_app.update_all_events_sidebar()

        messagebox.showinfo("Add Event", "Event added successfully.", parent=self.top)
        self.top.destroy()  # Close the event window

    def delete_event(self):
        """Delete the selected event"""
        selected = self.events_tree.selection()
        if not selected:
            messagebox.showwarning("Delete Event", "Please select an event first.", parent=self.top)
            return
        item = selected[0]
        values = self.events_tree.item(item, "values")
        description = values[0]

        # Find and delete event
        key = (self.year, self.month, self.day)
        if key in self.calendar_app.events:
            if self.event_id is not None:
                # Delete specific event
                del self.calendar_app.events[key][self.event_id]
                if not self.calendar_app.events[key]:
                    del self.calendar_app.events[key]
            else:
                # Delete selected event
                for idx, event in enumerate(self.calendar_app.events[key]):
                    if event["description"] == description:
                        del self.calendar_app.events[key][idx]
                        if not self.calendar_app.events[key]:
                            del self.calendar_app.events[key]
                        break
            self.calendar_app.save_events()
            self.populate_events()
            self.calendar_app.create_calendar(self.calendar_app.current_year, self.calendar_app.current_month)
            self.calendar_app.update_all_events_sidebar()
            messagebox.showinfo("Delete Event", "Event deleted.", parent=self.top)
        else:
            messagebox.showerror("Delete Event", "Unable to delete the selected event.", parent=self.top)

    def invite_people(self):
        """Invite people to the selected event within this event window"""
        # Get the selected event
        selected = self.events_tree.selection()
        if not selected:
            messagebox.showwarning("Invite People", "Please select an event first.", parent=self.top)
            return
        item = selected[0]
        values = self.events_tree.item(item, "values")
        description = values[0]

        # Find the event ID
        key = (self.year, self.month, self.day)
        if key in self.calendar_app.events:
            for idx, event in enumerate(self.calendar_app.events[key]):
                if event["description"] == description:
                    self.invite_people_to_event(key, idx)
                    return
        messagebox.showerror("Invite People", "Unable to find the selected event.", parent=self.top)

    def invite_people_globally(self):
        """Invite people to the selected event from the global event list"""
        selected = self.calendar_app.events_tree.selection()
        if not selected:
            messagebox.showwarning("Invite People", "Please select an event to invite people.")
            return
        item = selected[0]
        values = self.calendar_app.events_tree.item(item, "values")
        date = values[0]
        description = values[1]

        # Parse date
        try:
            year, month, day = map(int, date.split('-'))
        except ValueError:
            messagebox.showerror("Invite People", "Invalid date format.")
            return

        # Find event
        key = (year, month, day)
        if key in self.calendar_app.events:
            for idx, event in enumerate(self.calendar_app.events[key]):
                if event["description"] == description:
                    self.invite_people_to_event(key, idx)
                    return
        messagebox.showerror("Invite People", "Unable to invite people to the selected event.")

    def invite_people_to_event(self, key, event_id):
        """Handle inviting people to a specific event"""
        event = self.calendar_app.events.get(key, [])[event_id]
        # Ask how many people to invite
        num_people = simpledialog.askinteger(
            "Invite People",
            "How many people would you like to invite?",
            parent=self.top,
            minvalue=1,
            maxvalue=100
        )

        if not num_people:
            return

        invitees = []
        for i in range(num_people):
            name = simpledialog.askstring(
                "Invite People",
                f"Enter name for person {i + 1}:",
                parent=self.top
            )
            if name:
                invitees.append(name)
            else:
                break

        if invitees:
            if 'invitees' not in event:
                event['invitees'] = []
            event['invitees'].extend(invitees)

            # Update display
            self.calendar_app.save_events()
            self.populate_events()
            self.calendar_app.create_calendar(self.calendar_app.current_year, self.calendar_app.current_month)
            self.calendar_app.update_all_events_sidebar()
            messagebox.showinfo(
                "Invite People",
                f"Successfully invited {len(invitees)} people to the event.",
                parent=self.top
            )

    def on_event_double_click(self, event):
        """Handle double-clicking an event in the global event list"""
        selected = self.events_tree.selection()
        if not selected:
            return
        item = selected[0]
        values = self.events_tree.item(item, "values")
        date = values[0]
        description = values[1]

        # Parse date
        try:
            year, month, day = map(int, date.split('-'))
        except ValueError:
            messagebox.showerror("Error", "Invalid date format.")
            return

        # Find event
        key = (year, month, day)
        if key in self.events:
            for idx, event in enumerate(self.events[key]):
                if event["description"] == description:
                    # Open the event editing window
                    EventWindow(self, year, month, day, event_id=idx)
                    return
        messagebox.showerror("Error", "Unable to open the selected event.", parent=self.top)


class DateSelectionWindow:
    def __init__(self, calendar_app):
        self.calendar_app = calendar_app
        self.top = tk.Toplevel()
        self.top.title("Select Date for Event")
        self.top.geometry("400x300")
        self.top.configure(bg="lightyellow")

        # Date selection variables
        self.year_var = tk.IntVar(value=self.calendar_app.current_year)
        self.month_var = tk.IntVar(value=self.calendar_app.current_month)
        self.day_var = tk.IntVar(value=1)

        # Year selection
        year_label = tk.Label(self.top, text="Year:", bg="lightyellow")
        year_label.pack(pady=5)

        self.year_combobox = ttk.Combobox(
            self.top, textvariable=self.year_var, width=10, state="readonly"
        )
        self.year_combobox['values'] = list(range(1900, 2101))
        self.year_combobox.pack()

        # Month selection
        month_label = tk.Label(self.top, text="Month:", bg="lightyellow")
        month_label.pack(pady=5)

        self.month_combobox = ttk.Combobox(
            self.top, textvariable=self.month_var, width=10, state="readonly"
        )
        self.month_combobox['values'] = list(range(1, 13))
        self.month_combobox.pack()

        # Day selection
        day_label = tk.Label(self.top, text="Day:", bg="lightyellow")
        day_label.pack(pady=5)

        self.day_combobox = ttk.Combobox(
            self.top, textvariable=self.day_var, width=10, state="readonly"
        )
        self.day_combobox['values'] = list(range(1, 32))
        self.day_combobox.pack()

        # Submit button
        self.submit_button = tk.Button(
            self.top, text="Select Date", font=("Arial", 10), fg="blue",
            command=self.select_date, relief="raised", borderwidth=2, padx=10, pady=5
        )
        self.submit_button.pack(pady=20)

    def select_date(self):
        """Get and validate the user-selected date"""
        year = self.year_var.get()
        month = self.month_var.get()
        day = self.day_var.get()

        try:
            datetime(year, month, day)  # Validate date
        except ValueError:
            messagebox.showerror("Invalid Date", "The date entered is invalid.", parent=self.top)
            return

        self.top.destroy()
        self.calendar_app.open_event_window(year, month, day)


def main():
    root = tk.Tk()
    root.configure(bg="lightyellow")
    calendar_app = ResizableCalendar(root)
    root.mainloop()


if __name__ == "__main__":
    main()
